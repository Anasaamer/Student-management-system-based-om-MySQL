-- not operator

SELECT * FROM students
WHERE NOT gender = 'Male';
