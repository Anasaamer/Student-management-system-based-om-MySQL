-- or operator (F     F   =   F) other wise true

SELECT * FROM students
WHERE gender = 'Male' OR date_of_birth = '2000-01-01';
 