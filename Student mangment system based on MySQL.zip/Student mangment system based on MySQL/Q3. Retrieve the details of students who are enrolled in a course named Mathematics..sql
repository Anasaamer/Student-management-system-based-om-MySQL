-- Retrieve the details of students who are enrolled in a course named "Mathematics".

select students.first_name , students.last_name , courses.course_name
from students
join enrollments on students.student_id = enrollments.student_id
join courses on courses.course_id = enrollments.course_id
where 
courses.course_name = 'mathematics'