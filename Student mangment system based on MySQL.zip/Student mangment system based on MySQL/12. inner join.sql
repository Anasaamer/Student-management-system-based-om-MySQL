SELECT students.first_name, students.last_name, courses.course_name, enrollments.grades
FROM enrollments
INNER JOIN students ON enrollments.student_id = students.student_id
INNER JOIN courses ON enrollments.course_id = courses.course_id;
