update students 
set email = "john.doe@example.com"
where student_id = 1;