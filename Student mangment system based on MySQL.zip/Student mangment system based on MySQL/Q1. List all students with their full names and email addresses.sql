-- List all students with their full names and email addresses


SELECT CONCAT(first_name,last_name) AS full_name, email
FROM students;
