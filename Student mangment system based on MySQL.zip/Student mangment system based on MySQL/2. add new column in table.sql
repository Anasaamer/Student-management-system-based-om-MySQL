alter table students
add column address varchar(255);


UPDATE students
SET address = CASE student_id
    WHEN 1 THEN '123 Maple Street, Springfield, IL 62701'
    WHEN 2 THEN '456 Oak Avenue, Chicago, IL 60605'
    WHEN 3 THEN '789 Pine Road, Naperville, IL 60540'
    WHEN 4 THEN '321 Birch Lane, Peoria, IL 61614'
    WHEN 5 THEN '654 Cedar Drive, Aurora, IL 60502'
    WHEN 6 THEN '987 Elm Street, Rockford, IL 61107'
    WHEN 7 THEN '159 Walnut Street, Joliet, IL 60431'
    WHEN 8 THEN '753 Cherry Street, Decatur, IL 62521'
    WHEN 9 THEN '951 Poplar Road, Champaign, IL 61820'
    WHEN 10 THEN '357 Sycamore Lane, Bloomington, IL 61701'
    WHEN 11 THEN '246 Aspen Court, Schaumburg, IL 60193'
    WHEN 12 THEN '864 Willow Way, Evanston, IL 60201'
    WHEN 13 THEN '468 Maplewood Avenue, Elgin, IL 60120'
    WHEN 14 THEN '642 Magnolia Street, Waukegan, IL 60085'
    WHEN 15 THEN '284 Hickory Lane, Cicero, IL 60804'
END
WHERE student_id IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
