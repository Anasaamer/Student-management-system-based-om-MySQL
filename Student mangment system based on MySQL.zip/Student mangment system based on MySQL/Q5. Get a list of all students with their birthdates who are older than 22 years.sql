-- Get a list of all students with their birthdates who are older than 22 years

SELECT first_name, last_name, date_of_birth
FROM students
WHERE TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) > 22;
