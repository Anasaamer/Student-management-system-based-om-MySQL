select * from enrollments;
alter table enrollments rename column grade to grades 