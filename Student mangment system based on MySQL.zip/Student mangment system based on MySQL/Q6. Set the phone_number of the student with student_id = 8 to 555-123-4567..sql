-- Set the phone_number of the student with student_id = 8 to 555-123-4567.

UPDATE students
SET phone_number = '555-123-4567'
WHERE student_id = 8;
