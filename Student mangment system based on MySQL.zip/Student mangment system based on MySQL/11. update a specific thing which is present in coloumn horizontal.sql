UPDATE enrollments
SET grades = 'A+'
WHERE student_id = 4 AND course_id = 4;
