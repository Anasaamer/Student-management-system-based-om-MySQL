-- add operation ( T    T   =   T) other wise false

SELECT * FROM students
WHERE date_of_birth > '2000-01-01' AND gender = 'Male';