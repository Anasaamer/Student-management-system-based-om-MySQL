-- like operator 
select * from students 
where first_name like "j%";