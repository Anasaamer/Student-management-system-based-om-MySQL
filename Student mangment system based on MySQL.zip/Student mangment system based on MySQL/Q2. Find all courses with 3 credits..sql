-- Find all courses with 3 credits.

SELECT course_id, course_name, description, credits
FROM courses
WHERE credits = 3;
