select sum(credits) as total_credits from courses;

select sum(course_id) as total_courses from enrollments;

select sum(student_id) as total_student_id from enrollments