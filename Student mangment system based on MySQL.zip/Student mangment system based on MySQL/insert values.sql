INSERT INTO students (first_name, last_name, gender, date_of_birth, email, phone_number)
VALUES 
('John', 'Doe', 'Male', '2000-01-15', 'john.doe@example.com', '123-456-7890'),
('Jane', 'Smith', 'Female', '2001-02-20', 'jane.smith@example.com', '234-567-8901'),
('Michael', 'Johnson', 'Male', '1999-03-25', 'michael.johnson@example.com', '345-678-9012'),
('Emily', 'Davis', 'Female', '2002-04-30', 'emily.davis@example.com', '456-789-0123'),
('Robert', 'Brown', 'Male', '2001-05-10', 'robert.brown@example.com', '567-890-1234'),
('Linda', 'Wilson', 'Female', '1998-06-15', 'linda.wilson@example.com', '678-901-2345'),
('David', 'Garcia', 'Male', '1997-07-20', 'david.garcia@example.com', '789-012-3456'),
('Susan', 'Martinez', 'Female', '2000-08-25', 'susan.martinez@example.com', '890-123-4567'),
('James', 'Miller', 'Male', '2002-09-30', 'james.miller@example.com', '901-234-5678'),
('Sarah', 'Rodriguez', 'Female', '2001-10-05', 'sarah.rodriguez@example.com', '012-345-6789'),
('Daniel', 'Martinez', 'Male', '1999-11-10', 'daniel.martinez@example.com', '123-456-7890'),
('Nancy', 'Lopez', 'Female', '2002-12-15', 'nancy.lopez@example.com', '234-567-8901'),
('Thomas', 'Gonzalez', 'Male', '2000-01-20', 'thomas.gonzalez@example.com', '345-678-9012'),
('Patricia', 'Anderson', 'Female', '1998-02-25', 'patricia.anderson@example.com', '456-789-0123'),
('Christopher', 'Thomas', 'Male', '1997-03-30', 'christopher.thomas@example.com', '567-890-1234');



INSERT INTO courses (course_name, description, credits)
VALUES 
('Mathematics', 'Introduction to Mathematics', 3),
('Physics', 'Basic concepts of Physics', 4),
('Chemistry', 'Study of chemical reactions', 3),
('Biology', 'Understanding living organisms', 4),
('Computer Science', 'Introduction to computer programming', 4),
('History', 'Study of historical events', 3),
('Literature', 'Analysis of literary works', 3),
('Economics', 'Basic principles of economics', 3),
('Psychology', 'Introduction to psychology', 3),
('Sociology', 'Study of society and social behavior', 3),
('Art', 'Introduction to visual arts', 2),
('Music', 'Study of music theory and practice', 2),
('Philosophy', 'Introduction to philosophical thought', 3),
('Political Science', 'Understanding political systems', 3),
('Geography', 'Study of Earth and its features', 3);



INSERT INTO enrollments (student_id, course_id, enrollment_date, grade)
VALUES 
(1, 1, '2023-01-15', 'A'),
(2, 2, '2023-01-16', 'B'),
(3, 3, '2023-01-17', 'A'),
(4, 4, '2023-01-18', 'B'),
(5, 5, '2023-01-19', 'C'),
(6, 6, '2023-01-20', 'B'),
(7, 7, '2023-01-21', 'A'),
(8, 8, '2023-01-22', 'C'),
(9, 9, '2023-01-23', 'B'),
(10, 10, '2023-01-24', 'A'),
(11, 11, '2023-01-25', 'B'),
(12, 12, '2023-01-26', 'C'),
(13, 13, '2023-01-27', 'A'),
(14, 14, '2023-01-28', 'B'),
(15, 15, '2023-01-29', 'A');
