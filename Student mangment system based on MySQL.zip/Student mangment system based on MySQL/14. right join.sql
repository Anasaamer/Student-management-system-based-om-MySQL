SELECT students.first_name, students.last_name, courses.course_name, enrollments.grades
FROM courses
RIGHT JOIN enrollments ON courses.course_id = enrollments.course_id
RIGHT JOIN students ON enrollments.student_id = students.student_id;
